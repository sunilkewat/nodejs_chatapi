// Load Tesseract.js and initialize it
Tesseract.recognize(
    document.getElementById("imageInput").files[0], // Load the selected image file
    "eng", // Specify the language ("eng" for English)
    { logger: m => console.log("first option",m) } // Enable logging to see the progress and results
  )
    .then(result => {
      // Display the extracted text
      document.getElementById("result").textContent = result.text;
    })
    .catch(err => {
      console.error("option1",err);
    });
  
  // Function to trigger OCR
  function readText() {
    Tesseract.recognize(
      document.getElementById("imageInput").files[0],
      "eng",
      { logger: m => console.log("option2",m) }
    )
      .then(result => {
        let data = result.data;
        document.getElementById("result").textContent = data.text;
      })
      .catch(err => {
        console.error(err);
      });
  }
  