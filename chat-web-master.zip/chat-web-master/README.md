# React.js chat

CRA

Socket.io

![alt text](./public/img/ScreenShot.png)

## Available Scripts:

`npm install`

`npm run start`

`npm run build`

## Technologies

- reactjs
- redux
- react router dom
- Socket.io-client

## How It Work

- User Auth With Phone Number & Email
- Unique User Name
- Peer To Peer Chat
- Attach Photo && Movies File
- Contacts

### Chat Api

Git : https://github.com/MajAhd/chatApi-nodejs.git

### Mobile Application

Git :

### Desktop Application

Git : https://github.com/MajAhd/chat-desktop.git
