export const AppName = "Reactjs Chat";
export const mainApi = `http://localhost:8000`;
export const AuthApi = mainApi + `/api/auth`;
export const ChatApi = mainApi + `/api/chat`;
