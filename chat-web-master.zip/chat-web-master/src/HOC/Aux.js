import React from "react";
const Aux = props => <React.Fragment>{props.children}</React.Fragment>;
export default Aux;
